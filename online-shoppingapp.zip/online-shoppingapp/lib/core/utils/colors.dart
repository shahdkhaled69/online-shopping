import 'package:flutter/material.dart';

const backGround = Color(0xffF9F9F9);
const colorRed = Color(0xffDB3022);
