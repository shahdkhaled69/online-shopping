enum ThemeState { initial, ligth, dark }
