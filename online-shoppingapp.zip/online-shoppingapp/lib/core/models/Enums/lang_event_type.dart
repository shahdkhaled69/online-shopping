enum LangEventEnums { initialLang, arabicLang, englishLang }
