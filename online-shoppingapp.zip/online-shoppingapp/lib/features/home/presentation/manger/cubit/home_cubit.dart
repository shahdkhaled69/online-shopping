import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:shoping/features/home/data/models/categories_model.dart';
import 'package:shoping/features/home/data/models/get_prodcts_model/get_prodcts_model.dart';
import 'package:shoping/features/home/data/repos/home_repo.dart';

part 'home_state.dart';

class HomeCubit extends Cubit<HomeState> {
  HomeCubit(this.homeRepo) : super(HomeInitial());

  final HomeRepo homeRepo;
  Future<void> getegories() async {
    emit(GategoriesLoading());
    final response = await homeRepo.getegories();
    response.fold(
        (failure) => emit(GategoriesFaliure()),
        (categoriesModel) =>
            emit(Gategoriesuccess(getegories: categoriesModel)));
  }

  Future<void> getProdctsNew({required int num}) async {
    emit(GetProdctsNewLoading());
    final response = await homeRepo.getProdctsNew(num: num);
    response.fold((failure) => emit(GetProdctsNewFaliure()),
        (productModel) => emit(GetProdctsNewuccess(prodNew: productModel)));
  }

  Future<void> getProdctsClothes({required int num}) async {
    emit(GetProdctsClothesLoading());
    final response = await homeRepo.getProdctsClothes(num: num);
    response.fold(
        (failure) => emit(GetProdctsClothesFaliure()),
        (productModel) =>
            emit(GetProdctsClothesSuccess(prodClothes: productModel)));
  }

  Future<void> getProdctsElectronicDevices({required int num}) async {
    emit(GetProdctsElectronicDevicesLoading());
    final response = await homeRepo.getProdctsElectronicDevices(num: num);
    response.fold(
        (failure) => emit(GetProdctsElectronicDevicesFaliure()),
        (productModel) => emit(
            GetProdctsElectronicDevicesSuccess(prodElectronic: productModel)));
  }

  Future<void> getProdctsMedical({required int num}) async {
    emit(GetProdctsMedicalLoading());
    final response = await homeRepo.getProdctsMedical(num: num);
    response.fold(
        (failure) => emit(GetProdctsMedicalFaliure()),
        (productModel) =>
            emit(GetProdctsMedicalSuccess(prodMedical: productModel)));
  }

  Future<void> getProdctsSports({required int num}) async {
    emit(GetProdctsSportsLoading());
    final response = await homeRepo.getProdctsSports(num: num);
    response.fold(
        (failure) => emit(GetProdctsSportsFaliure()),
        (productModel) =>
            emit(GetProdctsSportsSuccess(prodSports: productModel)));
  }
}
