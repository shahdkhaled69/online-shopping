import 'package:expandable_page_view/expandable_page_view.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:shoping/core/utils/app_router.dart';
import 'package:shoping/features/home/data/models/image_model.dart';
import 'package:shoping/features/home/presentation/views/widget/image_apsectration.dart';

class MyCardPageViwe extends StatelessWidget {
  const MyCardPageViwe({super.key, required this.pageController});
  final PageController pageController;

  static const List<ImageModel> images = [
    ImageModel('assets/images/elediev.jpg'),
    ImageModel('assets/images/kor2.jpg'),
    ImageModel('assets/images/med.jpg'),
    ImageModel('assets/images/liht5.jpg'),
    ImageModel('assets/images/clos4.png'),
  ];
  void navigateToScreen(BuildContext context, int index) {
    switch (index) {
      case 0:
        GoRouter.of(context).push(AppRouter.kEletroinDeviecsViewAll);
        break;
      case 1:
        GoRouter.of(context).push(AppRouter.kMedicalViewAll);
        break;
      case 2:
        GoRouter.of(context).push(AppRouter.kSportsViewAll);
        break;
      case 3:
        GoRouter.of(context).push(AppRouter.kNewViewAll);
        break;
      case 4:
        GoRouter.of(context).push(AppRouter.kClothesViewAll);
        break;
      // أضف المزيد من الحالات إذا كان لديك المزيد من الصفحات
      default:
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    return ExpandablePageView(
      controller: pageController,
      scrollDirection: Axis.horizontal,
      children: List.generate(images.length, (index) {
        return ImageApsectratio(
          imageModel: images[index],
          onTap: () => navigateToScreen(context, index),
        );
      }),
    );
  }
}