class ImageModel {
  final String image;
  const ImageModel(this.image);
}
