package com.shoping.alaa.shoping

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
